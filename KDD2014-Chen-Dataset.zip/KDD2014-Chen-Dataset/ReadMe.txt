There are 2 large datasets in the folder, which are used in (Chen and Liu, KDD 2014). The first dataset contains reviews from 50 types of electronic products or domains. The second dataset contains reviews from 50 mixed types of non-electronic products or domains. Each domain has 1000 reviews.

The input directory should contain domain files. For each domain, there should be 2 files (can be opened by text editors):

domain.docs: each line (representing a document) contains a list of word ids. Here, a document is a sentence in a review after preprocessing.
domain.vocab: mapping from word id (starting from 0) to word.

If you are using these datasets, please cite the paper below:

Zhiyuan Chen and Bing Liu. Mining Topics in Documents: Standing on the Shoulders of Big Data. In Proceedings of KDD 2014.

If you want the original review text (before preprocessing), please send an email to czyuanacm@gmail.com.
