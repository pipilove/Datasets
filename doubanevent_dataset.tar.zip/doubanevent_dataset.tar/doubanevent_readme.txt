本数据集从收集自douban event，爬取了约100000个user信息、300000个event信息，以及3500000条check-in数据。

所有数据以.tsv文件格式组织。其中：

（1）users.tsv每行数据格式：

user_id	user_location

用\t分隔。user_id为用户名，user_location为用户地址。


（2）events.tsv每行数据格式：

event_id  event_location event_category

用\t分隔。


（3）all_user_event.tsv每行数据格式：

user_id	event_id

用\t分隔。每行表示一次check-in信息

